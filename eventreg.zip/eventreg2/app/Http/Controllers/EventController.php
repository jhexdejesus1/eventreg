<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Event;

class EventController extends Controller
{
    public function index()
    {
        $events = auth()->user()->events;
 
        return response()->json([
            'success' => true,
            'data' => $events
        ]);
    }
 
    public function show($id)
    {
        $post = auth()->user()->events()->find($id);
 
        if (!$post) {
            return response()->json([
                'success' => false,
                'message' => 'Event not found '
            ], 400);
        }
 
        return response()->json([
            'success' => true,
            'data' => $post->toArray()
        ], 400);
    }
 
    public function store(Request $request)
    {
        $this->validate($request, [
            'event_name' => 'required',
            'client_name' => 'required',
            'client_email' => 'required'
        ]);
 
        $event = new Event();
        $event->event_name = $request->event_name;
        $event->client_name = $request->client_name;
        $event->client_email = $request->client_email;
 
        if (auth()->user()->events()->save($event))
            return response()->json([
                'success' => true,
                'data' => $post->toArray()
            ]);
        else
            return response()->json([
                'success' => false,
                'message' => 'Event not added'
            ], 500);
    }
 
    public function update(Request $request, $id)
    {
        $event = auth()->user()->events()->find($id);
 
        if (!$event) {
            return response()->json([
                'success' => false,
                'message' => 'Event not found'
            ], 400);
        }
 
        $updated = $event->fill($request->all())->save();
 
        if ($updated)
            return response()->json([
                'success' => true
            ]);
        else
            return response()->json([
                'success' => false,
                'message' => 'Event can not be updated'
            ], 500);
    }
 
    public function destroy($id)
    {
        $event = auth()->user()->events()->find($id);
 
        if (!$event) {
            return response()->json([
                'success' => false,
                'message' => 'Event not found'
            ], 400);
        }
 
        if ($event->delete()) {
            return response()->json([
                'success' => true
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Event can not be deleted'
            ], 500);
        }
    }
}